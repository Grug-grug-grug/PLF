__________                 __    __           .____    .__  __    __  .__           __________.__              .__   
\______   \_______   _____/  |__/  |_ ___.__. |    |   |__|/  |__/  |_|  |   ____   \______   \__|__  ___ ____ |  |  
 |     ___/\_  __ \_/ __ \   __\   __<   |  | |    |   |  \   __\   __\  | _/ __ \   |     ___/  \  \/  // __ \|  |  
 |    |     |  | \/\  ___/|  |  |  |  \___  | |    |___|  ||  |  |  | |  |_\  ___/   |    |   |  |>    <\  ___/|  |__
 |____|     |__|    \___  >__|  |__|  / ____| |_______ \__||__|  |__| |____/\___  >  |____|   |__/__/\_ \\___  >____/
                        \/            \/              \/                        \/                     \/    \/           

Thanks for your purchase! 

In this Asset Pack:
-LICENCE
-README
-_PrettyLittlePixel_Interior_A2
-_PrettyLittlePixel_Interior_A4
-_PrettyLittlePixel_Interior_A5
-_PrettyLittlePixel_Interior_B
-_PrettyLittlePixel_Interior_C


Immediately usable by Rpg Maker Mv and MZ.
Can be use with other Rpg maker but need to be rearrange.



